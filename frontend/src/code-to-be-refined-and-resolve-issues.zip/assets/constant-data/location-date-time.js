// export const locationsList = [
//   { id: 'downtown', name: 'Downtown Flagship (100 Culinary Way)' },
//   { id: 'waterfront', name: 'Waterfront Bay (45 Marina Blvd)' },
//   { id: 'uptown', name: 'Uptown Express (880 Highland Ave)' },
// ]

export const timeSlots = [
  '12:00 PM', '12:30 PM', '01:00 PM', '01:30 PM', '02:00 PM',
  '05:30 PM', '06:00 PM', '06:30 PM', '07:00 PM', '07:30 PM', 
  '08:00 PM', '08:30 PM', '09:00 PM'
]

export const TIME_SLOTS = [
  { value: '12:00', label: '12:00 PM (Lunch)', hour: 12 },
  { value: '14:00', label: '02:00 PM (Lunch)', hour: 14 },
  { value: '18:00', label: '06:00 PM (Dinner)', hour: 18 },
  { value: '20:00', label: '08:00 PM (Dinner)', hour: 20 },
]

export const locationList = [
  {
    id: 'downtown',
    name: 'Downtown',
    address: '100 Culinary Way, Suite 400',
    phone: '+1 (555) 019-2834',
    status: 'Open Now',
    schedule: [
      { days: 'Monday – Thursday', time: '11:00 AM – 10:00 PM' },
      { days: 'Friday – Saturday', time: '11:00 AM – 11:30 PM' },
      { days: 'Sunday', time: '12:00 PM – 09:30 PM' },
    ]
  },
  {
    id: 'waterfront',
    name: 'Waterfront Bay',
    address: '45 Marina Boulevard, Dock 3',
    phone: '+1 (555) 019-5582',
    status: 'Open Now',
    schedule: [
      { days: 'Monday – Friday', time: '12:00 PM – 11:00 PM' },
      { days: 'Saturday – Sunday', time: '10:00 AM – 11:30 PM' },
    ]
  },
  {
    id: 'uptown',
    name: 'Uptown Express',
    address: '880 Highland Ave, Building B',
    phone: '+1 (555) 019-9941',
    status: 'Closed',
    schedule: [
      { days: 'Tuesday – Sunday', time: '04:00 PM – 10:30 PM' },
      { days: 'Monday', time: 'Closed for Maintenance' },
    ]
  }
]