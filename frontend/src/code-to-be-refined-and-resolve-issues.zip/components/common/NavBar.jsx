import { Link } from 'react-router-dom'
import { NavBarLink, NavBarButton } from './NavBarLinkAndButton'

const startBtn = "text-4xl font-bold text-[#c93400] underline"
const NavBar = () => {
  return (
    <div className="navbar bg-base-100 shadow-sm px-4">
      <div className="navbar-start">
        <Link to="/" className={`${startBtn}`}>
          Yummy.
        </Link>
      </div>
      
      <div className="navbar-center hidden lg:flex">
        <ul className="menu menu-horizontal px-1 gap-2">
          <NavBarLink to='/menu' name='Menu' />
          <NavBarLink to='/location-date-time' name='Location & Date Time' />
          <NavBarLink to='/contact' name='Contact Us' />
        </ul>
      </div>  

      <div className="navbar-end">
        <NavBarButton to='/book-table' name='Book a Table' />
      </div>
    </div>
  )
}

export default NavBar