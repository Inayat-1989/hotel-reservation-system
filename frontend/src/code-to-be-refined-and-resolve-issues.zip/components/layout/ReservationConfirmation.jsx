import React from 'react'

const ReservationConfirmation = ({ bookingData, referenceCode }) => {
  const createGoogleCalendarLink = () => {
    const { date, time, location } = bookingData
    const startTime = `${date.replace(/-/g, '')}T${time.replace(':', '')}00`
    
    const endHour = String(parseInt(time.split(':')[0]) + 2).padStart(2, '0')
    const endTime = `${date.replace(/-/g, '')}T${endHour}${time.split(':')[1]}00`

    const title = encodeURIComponent('Hotel Restaurant Table Reservation')
    const details = encodeURIComponent(`Reservation Ref: ${referenceCode}\nGuests: ${bookingData.guests}`)
    const loc = encodeURIComponent(`Hotel Restaurant - ${location}`)

    return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${startTime}/${endTime}&details=${details}&location=${loc}`
  }

  return (
    <div className="bg-white/5 border border-emerald-500/40 rounded-2xl p-8 text-center space-y-6">
      <div className="text-5xl">🎉</div>
      <h2 className="text-2xl font-bold text-emerald-400">Booking Confirmed!</h2>
      
      <div className="bg-black/40 border border-white/10 p-4 rounded-xl inline-block">
        <span className="text-xs text-gray-400 block uppercase tracking-wider">Reference Code</span>
        <span className="text-2xl font-mono font-bold text-[#c93400]">{referenceCode}</span>
      </div>

      <div className="text-sm text-gray-300 space-y-1">
        <p>Location: <strong className="text-white capitalize">{bookingData.location}</strong></p>
        <p>Date & Time: <strong className="text-white">{bookingData.date} at {bookingData.time}</strong></p>
        <p>Guests: <strong className="text-white">{bookingData.guests}</strong></p>
      </div>

      <div>
        <a
          href={createGoogleCalendarLink()}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-white/10 border border-white/20 text-white text-xs font-semibold hover:bg-white hover:text-black transition-colors"
        >
          📅 Add to Google Calendar
        </a>
      </div>
    </div>
  )
}

export default ReservationConfirmation