// Shared reservations storage
export const formList = []

// Add a pending reservation
export const addPendingReservation = (formData) => {
  const pendingBooking = {
    ...formData,
    id: formData.id || Date.now().toString(),
    status: 'pending',
    createdAt: Date.now()
  }
  formList.push(pendingBooking)
  return pendingBooking
}

// Finalize and confirm reservation after valid OTP
export const confirmReservation = (bookingId) => {
  const index = formList.findIndex((item) => item.id === bookingId)
  if (index !== -1) {
    formList[index].status = 'confirmed'
    return formList[index]
  }
  return null
}

// Remove/Purge reservation on timeout or cleanup
export const removeReservation = (bookingId) => {
  const index = formList.findIndex((item) => item.id === bookingId)
  if (index !== -1) {
    formList.splice(index, 1)
  }
}