import React, { useState, useEffect, useRef } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import NextPageButton from '../components/common/NextPageButton.jsx'
import GoogleCalendarButton from '../components/common/GoogleCalendarButton.jsx'
import { 
  confirmReservation, 
  removeReservation 
} from '../components/data-storage/form-data.js'

const EmailVerificationPage = () => {
  const navigate = useNavigate()
  const location = useLocation()
  
  // Pending booking passed from previous step
  const [booking, setBooking] = useState(location.state?.booking || null)

  const [otp, setOtp] = useState(['', '', '', '', '', ''])
  const [isVerified, setIsVerified] = useState(false)
  const [error, setError] = useState('')
  
  // 15-Minute Countdown Timer (900 seconds)
  const [timeLeft, setTimeLeft] = useState(900)
  
  // Track verification status in ref to access safely inside cleanup listeners
  const isVerifiedRef = useRef(false)
  const bookingRef = useRef(booking)

  useEffect(() => {
    isVerifiedRef.current = isVerified
    bookingRef.current = booking
  }, [isVerified, booking])

  // Cleanup handler when timer expires, component unmounts, or tab/page closes
  useEffect(() => {
    // 1. Tab/Window Close or Page Refresh Listener
    const handleBeforeUnload = (e) => {
      if (!isVerifiedRef.current && bookingRef.current?.id) {
        removeReservation(bookingRef.current.id)
      }
    }

    window.addEventListener('beforeunload', handleBeforeUnload)

    // 2. Component Unmount / Navigation Away Cleanup
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload)
      if (!isVerifiedRef.current && bookingRef.current?.id) {
        removeReservation(bookingRef.current.id)
      }
    }
  }, [])

  // 15-Minute Timer Logic
  useEffect(() => {
    if (isVerified || timeLeft <= 0) return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          // Timeout reached: purge pending reservation
          if (bookingRef.current?.id) {
            removeReservation(bookingRef.current.id)
          }
          setError('Hold timer expired. Your pending table reservation has been canceled.')
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [timeLeft, isVerified])

  const formatTimer = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const handleOtpChange = (element, index) => {
    if (isNaN(element.value)) return false
    const newOtp = [...otp]
    newOtp[index] = element.value
    setOtp(newOtp)

    if (element.nextSibling && element.value) {
      element.nextSibling.focus()
    }
  }

  const handleVerify = (e) => {
    e.preventDefault()
    const enteredCode = otp.join('')

    if (timeLeft <= 0) {
      setError('Your 15-minute hold timer has expired. Please start a new reservation.')
      return
    }

    // Demo OTP Verification (Accepts '123456' or any 6-digit input)
    if (enteredCode.length === 6) {
      // Mark as confirmed in storage
      const confirmedData = confirmReservation(booking.id)
      if (confirmedData) {
        setBooking(confirmedData)
      }
      setIsVerified(true)
      setError('')
    } else {
      // Invalid OTP: Do NOT delete form data; permit retry
      setError('Invalid verification code. Please check your email and try again.')
    }
  }

  const handleResendOtp = () => {
    if (timeLeft <= 0) return
    setOtp(['', '', '', '', '', ''])
    setError('')
    // Simulating new OTP dispatch
    alert(`A new verification code has been dispatched to ${booking?.email}`)
  }

  if (!booking) {
    return (
      <div className="w-full min-h-screen flex flex-col items-center justify-center text-white px-4">
        <p>No active booking found or your hold session expired.</p>
        <button 
          onClick={() => navigate('/book-table')} 
          className="mt-4 px-6 py-2 bg-[#c93400] text-white rounded-full font-bold hover:bg-white hover:text-[#c93400] transition-colors"
        >
          Start New Booking
        </button>
      </div>
    )
  }

  return (
    <div className="w-full min-h-screen flex flex-col items-center justify-center px-4 py-8 text-white animate-fade-in">
      <div className="w-full max-w-2xl bg-black/60 backdrop-blur-md border border-white/10 rounded-3xl p-6 md:p-10 shadow-2xl text-center">
        
        {!isVerified ? (
          <div className="space-y-6">
            <span className="text-xs font-bold uppercase tracking-widest text-[#c93400] bg-[#c93400]/10 px-3 py-1 rounded-full border border-[#c93400]/30">
              Step 3: Email Verification
            </span>

            <h1 className="text-3xl font-bold">Verify Your Reservation</h1>
            <p className="text-sm text-gray-300">
              We sent a verification code to <span className="text-white font-semibold">{booking.email}</span>.
            </p>

            {/* Countdown Hold Timer */}
            <div className="bg-amber-500/10 border border-amber-500/30 p-4 rounded-2xl max-w-sm mx-auto">
              <p className="text-xs text-amber-300 font-medium">Table Hold Time Remaining</p>
              <div className="text-3xl font-mono font-bold text-amber-400 mt-1">
                {formatTimer(timeLeft)}
              </div>
            </div>

            {error && (
              <p className="text-xs text-rose-400 bg-rose-500/10 border border-rose-500/30 p-2.5 rounded-xl">
                ⚠️ {error}
              </p>
            )}

            {/* 6-Digit OTP Form */}
            <form onSubmit={handleVerify} className="space-y-6">
              <div className="flex justify-center gap-2 md:gap-3">
                {otp.map((data, index) => (
                  <input
                    key={index}
                    type="text"
                    maxLength="1"
                    disabled={timeLeft <= 0}
                    value={data}
                    onChange={(e) => handleOtpChange(e.target, index)}
                    onFocus={(e) => e.target.select()}
                    className="w-10 h-12 md:w-12 md:h-14 bg-black/60 border border-white/20 rounded-xl text-center text-xl font-bold text-white focus:border-[#c93400] focus:outline-none transition-colors disabled:opacity-50"
                  />
                ))}
              </div>

              {timeLeft > 0 ? (
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-full bg-[#c93400] text-white text-base font-bold shadow-lg hover:bg-white hover:text-[#c93400] transition-all"
                >
                  Confirm & Finalize Reservation
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => navigate('/book-table')}
                  className="w-full py-3.5 rounded-full bg-rose-600 text-white text-base font-bold shadow-lg hover:bg-white hover:text-rose-600 transition-all"
                >
                  Hold Expired — Start Again
                </button>
              )}
            </form>

            {timeLeft > 0 && (
              <p className="text-xs text-gray-400">
                Didn't receive the code?{' '}
                <button 
                  onClick={handleResendOtp} 
                  className="text-[#c93400] underline font-semibold hover:text-white"
                >
                  Resend OTP
                </button>
              </p>
            )}
          </div>
        ) : (
          /* Final Confirmation View */
          <div className="space-y-6 animate-fade-in">
            <div className="text-5xl">🎉</div>
            <h1 className="text-3xl font-bold text-emerald-400">Reservation Completed!</h1>
            <p className="text-sm text-gray-300">
              Your table is officially locked in for <strong className="text-white">{booking.fullName}</strong>.
            </p>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-5 text-left text-xs md:text-sm space-y-2">
              <p><strong className="text-gray-400">Location:</strong> {booking.location}</p>
              <p><strong className="text-gray-400">Date & Time:</strong> {booking.date} at {booking.time}</p>
              <p><strong className="text-gray-400">Guests:</strong> {booking.guests} Guests</p>
              {booking.specialItems?.length > 0 && (
                <p><strong className="text-amber-400">Special Dishes:</strong> {booking.specialItems.map(i => i.title).join(', ')}</p>
              )}
            </div>

            <div className="pt-2">
              <GoogleCalendarButton booking={booking} />
            </div>

            <button
              onClick={() => navigate('/')}
              className="mt-4 px-8 py-3 rounded-full bg-white/10 text-white font-semibold hover:bg-white hover:text-black transition-colors"
            >
              Return to Home
            </button>
          </div>
        )}

      </div>

      <div className="mt-8">
        <NextPageButton to="/my-reservation" name="View Reservations" />
      </div>
    </div>
  )
}

export default EmailVerificationPage