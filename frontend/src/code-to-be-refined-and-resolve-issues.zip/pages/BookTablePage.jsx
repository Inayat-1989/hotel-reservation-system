import React, { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import NextPageButton from '../components/common/NextPageButton.jsx'
import { locationList, timeSlots } from '../assets/constant-data/location-date-time.js'
import { formList, addReservation } from '../components/data-storage/form-data.js'

const BookTablePage = () => {
  const navigate = useNavigate()
  const locationState = useLocation().state || {}
  const today = new Date().toISOString().split('T')[0]

  const [formData, setFormData] = useState({
    location: locationState.location || 'downtown',
    date: locationState.date || today,
    time: locationState.time || '18:00',
    guests: '2',
    fullName: '',
    email: '',
    phone: '',
    specialRequests: ''
  })

  const [isSubmitted, setIsSubmitted] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')
  const [showWarningModal, setShowWarningModal] = useState(false)

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
    if (errorMessage) setErrorMessage('')
  }

  // Calculate 24-hour gap requirement (R5)
  const check24HourGap = () => {
    const bookingDateTime = new Date(`${formData.date}T${formData.time}:00`)
    const now = new Date()
    const diffInHours = (bookingDateTime - now) / (1000 * 60 * 60)
    return diffInHours >= 24
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    // Check duplicate reservation
    const isDuplicate = formList.some((booking) => {
      const isSameUserBooking =
        booking.email.toLowerCase() === formData.email.trim().toLowerCase() &&
        booking.date === formData.date &&
        booking.time === formData.time

      const isSameSlotTaken =
        booking.location === formData.location &&
        booking.date === formData.date &&
        booking.time === formData.time

      return isSameUserBooking || isSameSlotTaken
    })

    if (isDuplicate) {
      setErrorMessage(
        'A reservation with these details or email already exists. Please select a different time or date.'
      )
      return
    }

    setErrorMessage('')

    if (check24HourGap()) {
      navigate('/special-menu-selection', { state: { bookingDetails: formData } })
    } else {
      setShowWarningModal(true)
    }
  }

  const handleConfirmWithoutSpecials = () => {
    const seatOnlyBooking = {
      ...formData,
      specialItems: []
    }
    addReservation(seatOnlyBooking)
    setShowWarningModal(false)
    setIsSubmitted(true)
  }

  return (
    <div className="w-full min-h-screen flex flex-col items-center justify-center px-4 py-8 animate-fade-in relative">
      
      <div className="w-full max-w-4xl bg-black/60 backdrop-blur-md border border-white/10 rounded-3xl p-6 md:p-10 shadow-2xl text-white">
        
        <h1 className="text-3xl md:text-5xl font-bold text-center text-[#c93400] mb-3">
          Book a Table
        </h1>
        <p className="text-gray-300 text-center text-sm md:text-base max-w-lg mx-auto mb-8">
          Reserve your dining experience with us. Choose your preferred location, date, and time.
        </p>

        {isSubmitted ? (
          <div className="bg-white/5 border border-emerald-500/40 rounded-2xl p-8 text-center space-y-4">
            <div className="text-5xl">🎉</div>
            <h2 className="text-2xl font-bold text-emerald-400">Reservation Confirmed!</h2>
            <p className="text-gray-300 text-sm max-w-md mx-auto">
              Thank you, <span className="text-white font-semibold">{formData.fullName}</span>. We have reserved a table for <span className="text-white font-semibold">{formData.guests} guests</span> on <span className="text-white font-semibold">{formData.date}</span> at <span className="text-[#c93400] font-semibold">{formData.time}</span>.
            </p>
            <p className="text-xs text-amber-300 bg-amber-500/10 p-2 rounded-lg inline-block">
              ⚠️ Note: Special items were not included as this booking is within 24 hours.
            </p>
            <br />
            <button
              onClick={() => setIsSubmitted(false)}
              className="mt-4 px-6 py-2.5 rounded-full bg-[#c93400] text-white font-semibold hover:bg-white hover:text-[#c93400] transition-colors"
            >
              Book Another Table
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            
            {errorMessage && (
              <div className="bg-rose-500/20 border border-rose-500/50 text-rose-300 px-4 py-3 rounded-xl text-xs md:text-sm text-center font-medium">
                ⚠️ {errorMessage}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              <div className="flex flex-col text-left">
                <label className="text-xs text-gray-300 mb-2 font-medium">Select Location</label>
                <select
                  name="location"
                  value={formData.location}
                  onChange={handleChange}
                  className="bg-black/50 border border-white/20 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#c93400] transition-colors"
                >
                  {locationList.map((loc) => (
                    <option key={loc.id} value={loc.id} className="bg-neutral-900 text-white">
                      {loc.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* R3 Party size enforcement (1 to 12 guests) */}
              <div className="flex flex-col text-left">
                <label className="text-xs text-gray-300 mb-2 font-medium">Number of Guests (Max 12)</label>
                <select
                  name="guests"
                  value={formData.guests}
                  onChange={handleChange}
                  className="bg-black/50 border border-white/20 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#c93400] transition-colors"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((num) => (
                    <option key={num} value={num} className="bg-neutral-900 text-white">
                      {num} {num === 1 ? 'Guest' : 'Guests'}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex flex-col text-left">
                <label className="text-xs text-gray-300 mb-2 font-medium">Date</label>
                <input
                  type="date"
                  name="date"
                  min={today}
                  value={formData.date}
                  onChange={handleChange}
                  className="bg-black/50 border border-white/20 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#c93400] transition-colors"
                  required
                />
              </div>

              <div className="flex flex-col text-left">
                <label className="text-xs text-gray-300 mb-2 font-medium">Time Slot</label>
                <select
                  name="time"
                  value={formData.time}
                  onChange={handleChange}
                  className="bg-black/50 border border-white/20 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#c93400] transition-colors"
                >
                  {timeSlots.map((slot) => (
                    <option key={slot} value={slot} className="bg-neutral-900 text-white">
                      {slot}
                    </option>
                  ))}
                </select>
              </div>

            </div>

            <div className="border-t border-white/10 pt-6 space-y-4 text-left">
              <h3 className="text-base font-semibold text-[#c93400]">Contact Details</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <input
                  type="text"
                  name="fullName"
                  placeholder="Full Name"
                  value={formData.fullName}
                  onChange={handleChange}
                  required
                  className="bg-black/50 border border-white/20 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#c93400] transition-colors"
                />
                <input
                  type="email"
                  name="email"
                  placeholder="Email Address"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="bg-black/50 border border-white/20 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#c93400] transition-colors"
                />
                <input
                  type="tel"
                  name="phone"
                  placeholder="Phone Number"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                  className="bg-black/50 border border-white/20 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#c93400] transition-colors"
                />
              </div>

              <textarea
                name="specialRequests"
                rows="2"
                placeholder="Special requests, dietary restrictions, or anniversary notes (optional)"
                value={formData.specialRequests}
                onChange={handleChange}
                className="w-full bg-black/50 border border-white/20 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#c93400] transition-colors"
              />
            </div>

            <div className="pt-4 text-center">
              <button
                type="submit"
                className="w-full md:w-auto px-10 py-3.5 rounded-full bg-[#c93400] text-white text-lg font-bold shadow-lg hover:bg-white hover:text-[#c93400] transition-all duration-300 transform hover:scale-105"
              >
                Proceed to Booking
              </button>
            </div>

          </form>
        )}

      </div>

      {showWarningModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-amber-500/50 rounded-2xl p-6 md:p-8 max-w-md w-full text-center space-y-4 shadow-2xl">
            <div className="text-4xl">⏰</div>
            <h3 className="text-xl font-bold text-amber-400">Special Menu Unavailable</h3>
            <p className="text-xs md:text-sm text-gray-300 leading-relaxed">
              Special menu items require at least <strong>1 day (24 hours)</strong> advance notice. Because your booking date/time is within 24 hours, pre-ordering special dishes will not be available.
            </p>
            <p className="text-xs text-gray-400">
              Would you like to proceed with seat reservation only, or adjust your date and time?
            </p>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                onClick={() => setShowWarningModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-white/20 text-white text-xs font-semibold hover:bg-white/10 transition-colors"
              >
                Adjust Date & Time
              </button>
              <button
                onClick={handleConfirmWithoutSpecials}
                className="flex-1 py-2.5 rounded-xl bg-[#c93400] text-white text-xs font-bold hover:bg-white hover:text-[#c93400] transition-colors"
              >
                Proceed Seat Only
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="mt-8">
        <NextPageButton to="/my-reservation" name="Reservations" />
      </div>

    </div>
  )
}

export default BookTablePage