import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import NextPageButton from '../components/common/NextPageButton.jsx'
import { locationList, TIME_SLOTS } from '../assets/constant-data/location-date-time.js'

const LocationDateTimePage = () => {
  const navigate = useNavigate()
  
  const now = new Date()
  const todayStr = now.toISOString().split('T')[0]
  const currentHour = now.getHours()

  const [selectedLocation, setSelectedLocation] = useState(locationList[0]?.id || '')
  const [selectedDate, setSelectedDate] = useState(todayStr)
  
  const availableTimeSlots = TIME_SLOTS.filter(slot => {
    if (selectedDate === todayStr) {
      return slot.hour > currentHour
    }
    return true
  })

  const [selectedTime, setSelectedTime] = useState(
    availableTimeSlots[0]?.value || '18:00'
  )

  const handleDateChange = (e) => {
    const newDate = e.target.value
    setSelectedDate(newDate)
    
    if (newDate === todayStr) {
      const validSlots = TIME_SLOTS.filter(s => s.hour > currentHour)
      if (validSlots.length > 0 && !validSlots.some(s => s.value === selectedTime)) {
        setSelectedTime(validSlots[0].value)
      }
    }
  }

  const handleProceed = () => {
    navigate('/book-table', {
      state: {
        location: selectedLocation,
        date: selectedDate,
        time: selectedTime,
      }
    })
  }

  return (
    <div className="w-full min-h-screen flex flex-col items-center justify-center px-4 py-8 animate-fade-in">
      <div className="w-full max-w-5xl bg-black/60 backdrop-blur-md border border-white/10 rounded-3xl p-6 md:p-10 shadow-2xl text-white">

        <h1 className="text-3xl md:text-5xl font-bold text-center text-[#c93400] mb-3">
          Locations & Opening Hours
        </h1>
        <p className="text-gray-300 text-center text-sm md:text-base max-w-lg mx-auto mb-8">
          Select a location to reserve a seat for that location.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8 text-left">
          {locationList.map((loc) => {
            const isSelected = selectedLocation === loc.id
            return (
              <div 
                key={loc.id}
                onClick={() => setSelectedLocation(loc.id)}
                className={`cursor-pointer p-6 rounded-2xl border transition-all duration-300 flex flex-col justify-between ${
                  isSelected 
                    ? 'bg-white/15 border-[#c93400] shadow-lg shadow-[#c93400]/20 scale-[1.02]' 
                    : 'bg-white/5 border-white/10 hover:border-[#c93400]/50 hover:bg-white/10'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h2 className="text-xl font-bold text-white">{loc.name}</h2>
                    <span className={`text-xs px-2.5 py-1 rounded-full font-semibold ${
                      loc.status === 'Open Now' 
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' 
                        : 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                    }`}>
                      {loc.status}
                    </span>
                  </div>

                  <p className="text-xs text-gray-400 mb-4">{loc.address}</p>
                  
                  <div className="space-y-2 border-t border-white/10 pt-3 mb-4">
                    {loc.schedule.map((item, index) => (
                      <div key={index} className="flex justify-between text-xs">
                        <span className="text-gray-300 font-medium">{item.days}</span>
                        <span className="text-white font-semibold">{item.time}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="text-xs text-gray-400 border-t border-white/10 pt-3 flex items-center justify-between">
                  <span>📞 {loc.phone}</span>
                  <span className={`text-[#c93400] font-bold ${isSelected ? 'opacity-100' : 'opacity-0'}`}>
                    Selected ✓
                  </span>
                </div>
              </div>
            )
          })}
        </div>

        <div className="bg-white/5 border border-white/10 rounded-2xl p-6 text-center">
          <h3 className="text-lg font-semibold text-[#c93400] mb-4">
            Plan Your Visit
          </h3>
          <div className="flex flex-wrap items-center justify-center gap-4">
            
            <div className="flex flex-col text-left">
              <label className="text-xs text-gray-300 mb-1 font-medium">Select Date</label>
              <input 
                type="date" 
                min={todayStr}
                value={selectedDate}
                onChange={handleDateChange}
                className="bg-black/50 border border-white/20 rounded-xl px-4 py-2 text-white text-sm focus:outline-none focus:border-[#c93400]" 
              />
            </div>

            <div className="flex flex-col text-left">
              <label className="text-xs text-gray-300 mb-1 font-medium">Select Time Slot</label>
              <select 
                value={selectedTime}
                onChange={(e) => setSelectedTime(e.target.value)}
                className="bg-black/50 border border-white/20 rounded-xl px-4 py-2 text-white text-sm focus:outline-none focus:border-[#c93400]"
              >
                {availableTimeSlots.length > 0 ? (
                  availableTimeSlots.map((slot) => (
                    <option key={slot.value} value={slot.value} className="bg-neutral-900 text-white">
                      {slot.label}
                    </option>
                  ))
                ) : (
                  <option value="" disabled className="bg-neutral-900 text-gray-400">
                    No remaining slots today
                  </option>
                )}
              </select>
            </div>

          </div>
        </div>

      </div>

      <div className="mt-8" onClick={handleProceed}>
        <NextPageButton to="/book-table" name="Book a Table" />
      </div>

    </div>
  )
}

export default LocationDateTimePage