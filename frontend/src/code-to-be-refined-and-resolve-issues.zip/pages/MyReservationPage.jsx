import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import NextPageButton from '../components/common/NextPageButton.jsx'
import { locationList } from '../assets/constant-data/location-date-time.js'
import { formList, removeReservation } from '../components/data-storage/form-data.js'

const MyReservationsPage = () => {
  const [reservations, setReservations] = useState([...formList])
  const [activeTab, setActiveTab] = useState('upcoming')

  const todayStr = new Date().toISOString().split('T')[0]

  const getLocationName = (id) => {
    const loc = locationList.find((l) => l.id === id)
    return loc ? loc.name : id
  }

  const filteredReservations = reservations.filter((res) => {
    if (activeTab === 'upcoming') {
      return res.date >= todayStr
    }
    return res.date < todayStr
  })

  const handleCancelReservation = (id) => {
    if (window.confirm('Are you sure you want to cancel this reservation?')) {
      removeReservation(id)
      setReservations([...formList])
    }
  }

  return (
    <div className="w-full min-h-screen flex flex-col items-center justify-center px-4 py-8 animate-fade-in">
      <div className="w-full max-w-4xl bg-black/60 backdrop-blur-md border border-white/10 rounded-3xl p-6 md:p-10 shadow-2xl text-white">
        
        <h1 className="text-3xl md:text-5xl font-bold text-center text-[#c93400] mb-3">
          My Reservations
        </h1>
        <p className="text-gray-300 text-center text-sm md:text-base max-w-lg mx-auto mb-8">
          Manage and view all your active dining bookings and previous visit history.
        </p>

        {/* Filter Tabs */}
        <div className="flex justify-center mb-8">
          <div className="bg-white/5 border border-white/10 p-1.5 rounded-full flex gap-2">
            <button
              onClick={() => setActiveTab('upcoming')}
              className={`px-6 py-2 rounded-full text-xs md:text-sm font-semibold transition-all ${
                activeTab === 'upcoming'
                  ? 'bg-[#c93400] text-white shadow-lg'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Upcoming ({reservations.filter((r) => r.date >= todayStr).length})
            </button>
            <button
              onClick={() => setActiveTab('past')}
              className={`px-6 py-2 rounded-full text-xs md:text-sm font-semibold transition-all ${
                activeTab === 'past'
                  ? 'bg-[#c93400] text-white shadow-lg'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Past ({reservations.filter((r) => r.date < todayStr).length})
            </button>
          </div>
        </div>

        {filteredReservations.length === 0 ? (
          <div className="bg-white/5 border border-white/10 rounded-2xl p-10 text-center space-y-4">
            <div className="text-4xl">🍽️</div>
            <h3 className="text-lg font-semibold text-gray-200">No {activeTab} reservations found</h3>
            <p className="text-xs text-gray-400 max-w-xs mx-auto">
              {activeTab === 'upcoming'
                ? "You don't have any upcoming tables reserved right now."
                : 'You have no past reservation history.'}
            </p>
            {activeTab === 'upcoming' && (
              <Link
                to="/book-table"
                className="inline-block mt-2 px-6 py-2.5 rounded-full bg-[#c93400] text-white text-xs font-bold hover:bg-white hover:text-[#c93400] transition-colors"
              >
                Book a Table Now
              </Link>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 text-left">
            {filteredReservations.map((res) => {
              const isUpcoming = res.date >= todayStr
              return (
                <div
                  key={res.id}
                  className="bg-white/5 border border-white/10 rounded-2xl p-5 md:p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:border-white/20 transition-all"
                >
                  <div className="space-y-2 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-lg font-bold text-white">
                        {getLocationName(res.location)}
                      </span>
                      <span
                        className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                          isUpcoming
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : 'bg-gray-500/20 text-gray-400 border border-gray-500/30'
                        }`}
                      >
                        {isUpcoming ? 'Confirmed' : 'Completed'}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-4 text-xs text-gray-300">
                      <span>📅 <strong className="text-white">{res.date}</strong></span>
                      <span>⏰ <strong className="text-white">{res.time}</strong></span>
                      <span>👥 <strong className="text-white">{res.guests} Guests</strong></span>
                    </div>

                    {res.specialRequests && (
                      <p className="text-xs text-gray-400 italic bg-black/30 p-2 rounded-lg border border-white/5">
                        "{res.specialRequests}"
                      </p>
                    )}
                  </div>

                  {isUpcoming && (
                    <div className="w-full md:w-auto flex md:flex-col justify-end gap-2 border-t md:border-t-0 border-white/10 pt-3 md:pt-0">
                      <button
                        onClick={() => handleCancelReservation(res.id)}
                        className="px-4 py-2 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/40 text-xs font-semibold hover:bg-rose-500 hover:text-white transition-colors"
                      >
                        Cancel Booking
                      </button>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}

      </div>

      <div className="mt-8">
        <NextPageButton to="/menu" name="Back to Menu" />
      </div>
    </div>
  )
}

export default MyReservationsPage